#!/usr/bin/env python3
"""CSV Insight — zero-dependency CSV profiler by twin.code."""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import statistics
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def read_text(path: Path) -> tuple[str, str]:
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            return raw.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace"), "utf-8 (replacement)"


def detect_dialect(sample: str) -> csv.Dialect:
    try:
        return csv.Sniffer().sniff(sample[:8192], delimiters=",;\t|")
    except csv.Error:
        return csv.excel


def parse_number(value: str) -> float | None:
    cleaned = value.strip().replace("\u00a0", "").replace(" ", "").replace(",", ".")
    if not cleaned:
        return None
    try:
        number = float(cleaned)
        return number if math.isfinite(number) else None
    except ValueError:
        return None


def profile_csv(path: Path) -> dict[str, Any]:
    text, encoding = read_text(path)
    dialect = detect_dialect(text)
    rows = list(csv.reader(text.splitlines(), dialect))
    if not rows:
        raise ValueError("CSV-файл пуст")

    headers = [cell.strip() or f"column_{index + 1}" for index, cell in enumerate(rows[0])]
    width = len(headers)
    data_rows = [(row + [""] * width)[:width] for row in rows[1:]]
    normalized = [tuple(cell.strip() for cell in row) for row in data_rows]
    duplicate_count = len(normalized) - len(set(normalized))

    columns = []
    for index, name in enumerate(headers):
        values = [row[index].strip() for row in data_rows]
        present = [value for value in values if value]
        numbers = [number for value in present if (number := parse_number(value)) is not None]
        numeric = bool(present) and len(numbers) / len(present) >= 0.8
        top = Counter(present).most_common(5)
        column: dict[str, Any] = {
            "name": name,
            "type": "number" if numeric else "text",
            "missing": len(values) - len(present),
            "missing_percent": round((len(values) - len(present)) / max(1, len(values)) * 100, 1),
            "unique": len(set(present)),
            "top_values": [{"value": value, "count": count} for value, count in top],
        }
        if numeric and numbers:
            column["numeric"] = {
                "min": min(numbers),
                "max": max(numbers),
                "mean": round(statistics.fmean(numbers), 2),
                "median": round(statistics.median(numbers), 2),
            }
        columns.append(column)

    missing_cells = sum(column["missing"] for column in columns)
    total_cells = max(1, len(data_rows) * width)
    quality_score = max(0, round(100 - missing_cells / total_cells * 65 - duplicate_count / max(1, len(data_rows)) * 35))
    return {
        "source": path.name,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "fingerprint": hashlib.sha256(path.read_bytes()).hexdigest()[:12],
        "encoding": encoding,
        "delimiter": getattr(dialect, "delimiter", ","),
        "rows": len(data_rows),
        "columns_count": width,
        "duplicate_rows": duplicate_count,
        "missing_cells": missing_cells,
        "quality_score": quality_score,
        "columns": columns,
        "preview": [dict(zip(headers, row)) for row in data_rows[:6]],
    }


def fmt(value: Any) -> str:
    if isinstance(value, float):
        return f"{value:,.2f}".replace(",", " ")
    return f"{value:,}".replace(",", " ") if isinstance(value, int) else str(value)


def build_report(data: dict[str, Any]) -> str:
    e = html.escape
    column_cards = []
    for column in data["columns"]:
        top = "".join(
            f'<li><span>{e(item["value"][:42])}</span><strong>{item["count"]}</strong></li>'
            for item in column["top_values"][:3]
        ) or '<li class="empty">Нет значений</li>'
        numeric = ""
        if "numeric" in column:
            n = column["numeric"]
            numeric = f'''<div class="range"><span>min <b>{fmt(n["min"])}</b></span><span>avg <b>{fmt(n["mean"])}</b></span><span>max <b>{fmt(n["max"])}</b></span></div>'''
        column_cards.append(f'''
          <article class="column-card">
            <div class="column-head"><div><small>КОЛОНКА</small><h3>{e(column["name"])}</h3></div><span class="type">{column["type"]}</span></div>
            <div class="column-stats"><span><b>{fmt(column["unique"])}</b> уникальных</span><span><b>{column["missing_percent"]}%</b> пропусков</span></div>
            <div class="bar"><i style="width:{max(2, 100-column["missing_percent"])}%"></i></div>
            {numeric}
            <h4>Частые значения</h4><ul>{top}</ul>
          </article>''')

    preview_headers = "".join(f"<th>{e(col['name'])}</th>" for col in data["columns"])
    preview_rows = "".join(
        "<tr>" + "".join(f"<td>{e(str(row.get(col['name'], ''))[:70])}</td>" for col in data["columns"]) + "</tr>"
        for row in data["preview"]
    )
    return f'''<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CSV Insight · {e(data["source"])}</title>
<style>
:root{{--bg:#090c10;--panel:#11161d;--line:#29313b;--text:#f3f5f6;--muted:#8d98a6;--accent:#b9ff43;--cyan:#61d6ff}}*{{box-sizing:border-box}}body{{margin:0;color:var(--text);background:radial-gradient(circle at 80% 0,rgba(185,255,67,.09),transparent 29%),var(--bg);font-family:Inter,system-ui,sans-serif}}.shell{{width:min(1320px,calc(100% - 32px));margin:auto;padding:32px 0 70px}}header{{display:flex;align-items:center;justify-content:space-between;padding:0 0 28px;border-bottom:1px solid var(--line)}}.brand{{display:flex;align-items:center;gap:12px}}.logo{{width:44px;height:44px;display:grid;place-items:center;border-radius:13px;color:#10150a;background:var(--accent);font-weight:950}}.brand strong,.brand small{{display:block}}.brand small,.meta{{color:var(--muted);font-size:11px}}.badge{{padding:7px 10px;border:1px solid #40502a;border-radius:99px;color:var(--accent);font-size:10px;font-weight:800}}.hero{{padding:62px 0 36px;display:grid;grid-template-columns:1fr auto;gap:30px;align-items:end}}.eyebrow{{color:var(--accent);font-size:10px;font-weight:900;letter-spacing:.16em}}h1{{max-width:10ch;margin:9px 0 15px;font-size:clamp(44px,7vw,90px);line-height:.88;letter-spacing:-.07em}}.hero p{{max-width:580px;color:var(--muted);line-height:1.6}}.score{{width:150px;height:150px;display:grid;place-content:center;border:1px solid #455a2c;border-radius:50%;text-align:center;background:radial-gradient(circle,rgba(185,255,67,.13),transparent 67%)}}.score strong{{font-size:48px;line-height:1}}.score small{{color:var(--muted)}}.metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}}.metric{{padding:20px;border:1px solid var(--line);border-radius:15px;background:var(--panel)}}.metric span,.column-card small{{color:var(--muted);font-size:9px;letter-spacing:.11em}}.metric strong{{display:block;margin-top:9px;font-size:28px}}.section-title{{margin:55px 0 16px;display:flex;align-items:end;justify-content:space-between}}.section-title h2{{margin:0;font-size:28px;letter-spacing:-.04em}}.columns{{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}}.column-card{{padding:20px;border:1px solid var(--line);border-radius:16px;background:var(--panel)}}.column-head{{display:flex;justify-content:space-between;gap:15px}}h3{{margin:4px 0 0;font-size:16px}}.type{{height:max-content;padding:5px 7px;border-radius:7px;color:var(--cyan);background:rgba(97,214,255,.08);font-size:9px}}.column-stats{{margin-top:21px;display:flex;gap:20px;color:var(--muted);font-size:10px}}.column-stats b{{color:var(--text);font-size:15px}}.bar{{height:4px;margin:10px 0 18px;overflow:hidden;border-radius:9px;background:#080b0f}}.bar i{{display:block;height:100%;background:linear-gradient(90deg,var(--accent),var(--cyan))}}.range{{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;padding:11px;border-radius:10px;background:#0b0f14}}.range span{{color:var(--muted);font-size:8px}}.range b{{display:block;margin-top:4px;color:var(--text);font-size:10px}}h4{{margin:18px 0 8px;color:var(--muted);font-size:9px;text-transform:uppercase;letter-spacing:.1em}}ul{{margin:0;padding:0;list-style:none}}li{{padding:6px 0;display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid #20262e;font-size:10px}}li span{{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}li strong{{color:var(--accent)}}.table-wrap{{overflow:auto;border:1px solid var(--line);border-radius:16px}}table{{width:100%;border-collapse:collapse;background:var(--panel);font-size:11px}}th,td{{max-width:240px;padding:13px 15px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}th{{color:var(--muted);background:#0d1116;font-size:9px}}footer{{margin-top:35px;color:var(--muted);font-size:10px}}@media(max-width:900px){{.columns{{grid-template-columns:1fr 1fr}}.metrics{{grid-template-columns:1fr 1fr}}}}@media(max-width:600px){{.hero{{grid-template-columns:1fr}}.score{{width:110px;height:110px}}.columns{{grid-template-columns:1fr}}}}
</style></head><body><main class="shell"><header><div class="brand"><span class="logo">CSV</span><span><strong>CSV Insight</strong><small>zero-dependency profiler · twin.code</small></span></div><span class="badge">REPORT READY</span></header>
<section class="hero"><div><span class="eyebrow">DATA QUALITY REPORT</span><h1>{e(data["source"])}</h1><p>Автоматический профиль структуры, заполненности и повторов. Отчёт не отправляет данные во внешние сервисы.</p><div class="meta">SHA256 {data["fingerprint"]} · {e(data["encoding"])} · разделитель «{e(data["delimiter"]) }»</div></div><div class="score"><strong>{data["quality_score"]}</strong><small>качество / 100</small></div></section>
<section class="metrics"><div class="metric"><span>СТРОК</span><strong>{fmt(data["rows"])}</strong></div><div class="metric"><span>КОЛОНОК</span><strong>{data["columns_count"]}</strong></div><div class="metric"><span>ПРОПУСКОВ</span><strong>{fmt(data["missing_cells"])}</strong></div><div class="metric"><span>ДУБЛИКАТОВ</span><strong>{fmt(data["duplicate_rows"])}</strong></div></section>
<div class="section-title"><h2>Профиль колонок</h2><span class="meta">{data["columns_count"]} параметров</span></div><section class="columns">{"".join(column_cards)}</section>
<div class="section-title"><h2>Предпросмотр данных</h2><span class="meta">первые {len(data["preview"])} строк</span></div><div class="table-wrap"><table><thead><tr>{preview_headers}</tr></thead><tbody>{preview_rows}</tbody></table></div>
<footer>Сформировано CSV Insight · twin.code · {e(data["generated_at"])}</footer></main></body></html>'''


def main() -> None:
    parser = argparse.ArgumentParser(description="Профилирование CSV и HTML-отчёт")
    parser.add_argument("source", type=Path, help="Путь к CSV-файлу")
    parser.add_argument("--output", "-o", type=Path, default=Path("csv-insight-report.html"))
    parser.add_argument("--json", dest="json_output", type=Path)
    args = parser.parse_args()
    data = profile_csv(args.source)
    args.output.write_text(build_report(data), encoding="utf-8")
    if args.json_output:
        args.json_output.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"CSV Insight: {data['rows']} rows, {data['columns_count']} columns, quality {data['quality_score']}/100")
    print(f"HTML report: {args.output.resolve()}")


if __name__ == "__main__":
    main()
