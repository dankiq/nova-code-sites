import asyncio
import logging
import os

from aiogram import Bot, Dispatcher, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import Message
from dotenv import load_dotenv


router = Router()


@router.message(CommandStart())
async def start(message: Message) -> None:
    await message.answer(
        "Здравствуйте! Это открытый starter-kit twin.code. "
        "Напишите сообщение, и бот покажет базовую обработку входящего текста."
    )


@router.message(Command("help"))
async def help_command(message: Message) -> None:
    await message.answer("Команды: /start, /help. Остальные сообщения бот повторяет обратно.")


@router.message()
async def echo(message: Message) -> None:
    if message.text:
        await message.answer(f"Получено: {message.text}")
    else:
        await message.answer("В starter-kit реализована только обработка текста.")


async def main() -> None:
    load_dotenv()
    token = os.getenv("BOT_TOKEN")
    if not token:
        raise RuntimeError("Добавьте BOT_TOKEN в файл .env")

    logging.basicConfig(level=logging.INFO)
    dispatcher = Dispatcher()
    dispatcher.include_router(router)

    async with Bot(token=token) as bot:
        await dispatcher.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
