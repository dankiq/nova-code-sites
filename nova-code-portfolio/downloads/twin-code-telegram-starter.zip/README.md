# Telegram Starter Kit by twin.code

Небольшой открытый пример бота на aiogram 3. Он показывает структуру проекта, подключение роутера, команды и обработку входящего текста.

В starter-kit намеренно нет бизнес-сценариев, FSM, базы данных, админ-панели и интеграций. Полные версии LeadPilot, SlotMate, OrderFlow и SupportDesk доступны после покупки или разработки под Ваш процесс.

## Запуск

1. Создайте бота через [@BotFather](https://t.me/BotFather).
2. Скопируйте `.env.example` в `.env` и добавьте токен.
3. Установите зависимости: `python -m pip install -r requirements.txt`.
4. Запустите: `python bot.py`.

## Лицензия

Starter-kit распространяется по лицензии MIT. Коммерческие сценарии twin.code в архив не входят.
