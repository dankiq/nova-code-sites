#!/usr/bin/env node
import { createHash } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";

const ignored = new Set([".git", "node_modules", ".next", "dist", "out"]);
const assetTypes = new Set([".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".mp4", ".webm", ".woff", ".woff2", ".ttf", ".css", ".js", ".mjs"]);

function parseArgs(argv) {
  const args = { root: ".", output: "assetguard-report.html", json: null, largeKb: 250 };
  const values = [...argv];
  if (values[0] && !values[0].startsWith("-")) args.root = values.shift();
  while (values.length) {
    const flag = values.shift();
    if (flag === "--output" || flag === "-o") args.output = values.shift();
    else if (flag === "--json") args.json = values.shift();
    else if (flag === "--large-kb") args.largeKb = Number(values.shift()) || 250;
  }
  return args;
}

async function walk(root, current = root) {
  const entries = await fs.readdir(current, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (ignored.has(entry.name)) continue;
    const absolute = path.join(current, entry.name);
    if (entry.isDirectory()) files.push(...await walk(root, absolute));
    else if (entry.isFile()) files.push({ absolute, relative: path.relative(root, absolute).replaceAll("\\", "/") });
  }
  return files;
}

function hash(buffer) { return createHash("sha256").update(buffer).digest("hex"); }
function esc(value) { return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[char]); }
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(2)} MB`;
}

function extractReferences(text, extension) {
  const refs = [];
  const patterns = extension === ".css"
    ? [/url\(\s*["']?([^"')]+)["']?\s*\)/gi, /@import\s+["']([^"']+)["']/gi]
    : [/(?:src|href|poster)\s*=\s*["']([^"']+)["']/gi, /srcset\s*=\s*["']([^"']+)["']/gi];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      if (pattern.source.startsWith("srcset")) {
        refs.push(...match[1].split(",").map((part) => part.trim().split(/\s+/)[0]));
      } else refs.push(match[1]);
    }
  }
  return refs.filter((ref) => ref && !/^(?:https?:|data:|mailto:|tel:|#|javascript:)/i.test(ref));
}

async function audit(rootInput, largeKb) {
  const root = path.resolve(rootInput);
  const files = await walk(root);
  const records = [];
  const hashGroups = new Map();
  const broken = [];

  for (const file of files) {
    const buffer = await fs.readFile(file.absolute);
    const extension = path.extname(file.relative).toLowerCase();
    const record = { path: file.relative, extension: extension || "other", size: buffer.length, hash: hash(buffer) };
    records.push(record);
    if (!hashGroups.has(record.hash)) hashGroups.set(record.hash, []);
    hashGroups.get(record.hash).push(record);

    if (extension === ".html" || extension === ".htm" || extension === ".css") {
      for (const reference of extractReferences(buffer.toString("utf8"), extension)) {
        const clean = decodeURIComponent(reference.split(/[?#]/)[0]);
        const target = clean.startsWith("/") ? path.join(root, clean) : path.resolve(path.dirname(file.absolute), clean);
        try { await fs.access(target); }
        catch { broken.push({ source: file.relative, reference }); }
      }
    }
  }

  const assets = records.filter((file) => assetTypes.has(file.extension));
  const duplicates = [...hashGroups.values()].filter((group) => group.length > 1 && group[0].size > 0);
  const large = assets.filter((file) => file.size >= largeKb * 1024).sort((a, b) => b.size - a.size);
  const totalSize = records.reduce((sum, file) => sum + file.size, 0);
  const duplicateWaste = duplicates.reduce((sum, group) => sum + group[0].size * (group.length - 1), 0);
  const score = Math.max(0, Math.round(100 - broken.length * 9 - large.length * 4 - Math.min(24, duplicateWaste / Math.max(1, totalSize) * 100)));

  return { root, generatedAt: new Date().toISOString(), score, files: records.length, assets: assets.length, totalSize, largeKb, large, broken, duplicates, duplicateWaste };
}

function renderReport(data) {
  const largeRows = data.large.length ? data.large.map((file) => `<tr><td><span class="file-icon">${esc(file.extension.slice(1) || "FILE")}</span>${esc(file.path)}</td><td>${formatBytes(file.size)}</td><td><span class="tag warn">оптимизировать</span></td></tr>`).join("") : '<tr><td colspan="3" class="empty">Тяжёлых ресурсов не найдено</td></tr>';
  const brokenRows = data.broken.length ? data.broken.map((item) => `<tr><td>${esc(item.source)}</td><td><code>${esc(item.reference)}</code></td><td><span class="tag bad">не найден</span></td></tr>`).join("") : '<tr><td colspan="3" class="empty">Все локальные ссылки доступны</td></tr>';
  const duplicateRows = data.duplicates.length ? data.duplicates.map((group) => `<tr><td>${group.map((file) => esc(file.path)).join("<br>")}</td><td>${group.length} копии</td><td>${formatBytes(group[0].size * (group.length - 1))}</td></tr>`).join("") : '<tr><td colspan="3" class="empty">Повторов не найдено</td></tr>';
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AssetGuard Report</title><style>
:root{--bg:#080a0e;--panel:#11151b;--line:#29303a;--text:#f4f5f7;--muted:#8c96a4;--accent:#baff42;--orange:#ffb458;--red:#ff707c}*{box-sizing:border-box}body{margin:0;color:var(--text);background:radial-gradient(circle at 76% 0,rgba(186,255,66,.1),transparent 31%),var(--bg);font-family:Inter,system-ui,sans-serif}.shell{width:min(1280px,calc(100% - 32px));margin:auto;padding:28px 0 80px}.topbar{padding-bottom:24px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--line)}.brand{display:flex;align-items:center;gap:12px}.logo{width:44px;height:44px;display:grid;place-items:center;border-radius:12px;color:#101408;background:var(--accent);font-weight:950}.brand strong,.brand small{display:block}.brand small{margin-top:2px;color:var(--muted);font-size:10px}.ready{padding:7px 10px;border:1px solid #47572f;border-radius:99px;color:var(--accent);font-size:9px;font-weight:900;letter-spacing:.1em}.hero{padding:58px 0 38px;display:grid;grid-template-columns:1fr auto;align-items:end}.eyebrow{color:var(--accent);font-size:10px;font-weight:900;letter-spacing:.14em}h1{max-width:11ch;margin:9px 0 13px;font-size:clamp(46px,7vw,88px);line-height:.88;letter-spacing:-.07em}.hero p{max-width:610px;color:var(--muted);line-height:1.6}.score{width:155px;height:155px;display:grid;place-content:center;border:1px solid #4d6031;border-radius:50%;text-align:center;background:radial-gradient(circle,rgba(186,255,66,.13),transparent 67%)}.score b{font-size:49px}.score span{color:var(--muted);font-size:10px}.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.metric{padding:20px;border:1px solid var(--line);border-radius:15px;background:var(--panel)}.metric small{color:var(--muted);font-size:9px;letter-spacing:.1em}.metric strong{display:block;margin-top:8px;font-size:27px}.section{margin-top:42px;border:1px solid var(--line);border-radius:17px;overflow:hidden;background:var(--panel)}.section-title{padding:18px 20px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--line)}h2{margin:0;font-size:17px}.section-title span{color:var(--muted);font-size:10px}table{width:100%;border-collapse:collapse;font-size:11px}th,td{padding:14px 20px;border-bottom:1px solid #20262e;text-align:left}th{color:var(--muted);background:#0d1116;font-size:9px;letter-spacing:.09em}td:first-child{max-width:630px}code{padding:4px 6px;border-radius:5px;color:#ffb7bd;background:rgba(255,112,124,.08)}.tag{padding:5px 7px;border-radius:7px;font-size:8px;font-weight:850}.warn{color:var(--orange);background:rgba(255,180,88,.08)}.bad{color:var(--red);background:rgba(255,112,124,.08)}.file-icon{display:inline-block;min-width:38px;margin-right:9px;padding:4px 5px;border-radius:5px;color:var(--accent);background:rgba(186,255,66,.07);font-size:7px;text-align:center}.empty{padding:30px;text-align:center;color:var(--muted)}footer{margin-top:28px;color:var(--muted);font-size:10px}@media(max-width:700px){.hero{grid-template-columns:1fr}.score{width:110px;height:110px}.metrics{grid-template-columns:1fr 1fr}.section{overflow:auto}table{min-width:650px}}
</style></head><body><main class="shell"><header class="topbar"><div class="brand"><span class="logo">AG</span><span><strong>AssetGuard</strong><small>web asset auditor · twin.code</small></span></div><span class="ready">AUDIT COMPLETE</span></header><section class="hero"><div><span class="eyebrow">PERFORMANCE & INTEGRITY</span><h1>Ресурсы под контролем.</h1><p>Проверка веса файлов, локальных ссылок и одинаковых ресурсов. Один автономный отчёт для быстрой подготовки сайта к публикации.</p></div><div class="score"><b>${data.score}</b><span>здоровье / 100</span></div></section><section class="metrics"><div class="metric"><small>ФАЙЛОВ</small><strong>${data.files}</strong></div><div class="metric"><small>РЕСУРСОВ</small><strong>${data.assets}</strong></div><div class="metric"><small>ОБЩИЙ ВЕС</small><strong>${formatBytes(data.totalSize)}</strong></div><div class="metric"><small>ЛИШНИЙ ВЕС</small><strong>${formatBytes(data.duplicateWaste)}</strong></div></section><section class="section"><div class="section-title"><h2>Тяжёлые ресурсы</h2><span>порог ${data.largeKb} KB · найдено ${data.large.length}</span></div><table><thead><tr><th>ФАЙЛ</th><th>РАЗМЕР</th><th>СТАТУС</th></tr></thead><tbody>${largeRows}</tbody></table></section><section class="section"><div class="section-title"><h2>Битые ссылки</h2><span>найдено ${data.broken.length}</span></div><table><thead><tr><th>ИСТОЧНИК</th><th>ССЫЛКА</th><th>СТАТУС</th></tr></thead><tbody>${brokenRows}</tbody></table></section><section class="section"><div class="section-title"><h2>Дубликаты</h2><span>групп ${data.duplicates.length}</span></div><table><thead><tr><th>ФАЙЛЫ</th><th>КОПИИ</th><th>ЭКОНОМИЯ</th></tr></thead><tbody>${duplicateRows}</tbody></table></section><footer>Сформировано AssetGuard · ${esc(data.generatedAt)} · ${esc(data.root)}</footer></main></body></html>`;
}

const args = parseArgs(process.argv.slice(2));
try {
  const report = await audit(args.root, args.largeKb);
  await fs.writeFile(args.output, renderReport(report), "utf8");
  if (args.json) await fs.writeFile(args.json, JSON.stringify(report, null, 2), "utf8");
  console.log(`AssetGuard: ${report.files} files, ${report.broken.length} broken refs, score ${report.score}/100`);
  console.log(`HTML report: ${path.resolve(args.output)}`);
  process.exitCode = report.broken.length ? 2 : 0;
} catch (error) {
  console.error(`AssetGuard error: ${error.message}`);
  process.exitCode = 1;
}
