#!/usr/bin/env node
import { readFile, writeFile } from "node:fs/promises";
import { performance } from "node:perf_hooks";

const args = process.argv.slice(2);
const option = (name, fallback) => {
  const index = args.indexOf(name);
  return index >= 0 ? args[index + 1] : fallback;
};
const configPath = option("--config", "targets.json");
const jsonPath = option("--json", "report.json");
const htmlPath = option("--html", "report.html");
const retries = Math.max(0, Number(option("--retries", "1")));

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
}

async function probe(target) {
  const expected = target.expectStatus || [200, 299];
  const timeout = target.timeoutMs || 6000;
  let last;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    const started = performance.now();
    try {
      const response = await fetch(target.url, {
        method: target.method || "GET",
        headers: { "user-agent": "UptimePulse/1.0" },
        signal: controller.signal,
        redirect: "follow"
      });
      const body = target.contains ? await response.text() : "";
      const latency = Math.round(performance.now() - started);
      const statusOk = response.status >= expected[0] && response.status <= expected[1];
      const contentOk = !target.contains || body.toLowerCase().includes(target.contains.toLowerCase());
      last = {
        name: target.name,
        url: target.url,
        status: response.status,
        latency,
        ok: statusOk && contentOk,
        contentCheck: target.contains ? contentOk : null,
        attempt: attempt + 1,
        checkedAt: new Date().toISOString(),
        error: statusOk ? (contentOk ? null : `Не найден текст: ${target.contains}`) : `HTTP ${response.status}`
      };
      if (last.ok) break;
    } catch (error) {
      last = {
        name: target.name,
        url: target.url,
        status: null,
        latency: Math.round(performance.now() - started),
        ok: false,
        contentCheck: null,
        attempt: attempt + 1,
        checkedAt: new Date().toISOString(),
        error: error.name === "AbortError" ? `Таймаут ${timeout} мс` : error.message
      };
    } finally {
      clearTimeout(timer);
    }
  }
  return last;
}

async function runPool(items, concurrency) {
  const results = new Array(items.length);
  let cursor = 0;
  const worker = async () => {
    while (cursor < items.length) {
      const index = cursor++;
      results[index] = await probe(items[index]);
    }
  };
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
  return results;
}

function buildHtml(report) {
  const cards = report.results.map((item) => `
    <article class="service ${item.ok ? "ok" : "fail"}">
      <div class="service__top"><span class="dot"></span><strong>${escapeHtml(item.name)}</strong><b>${item.ok ? "ONLINE" : "FAILED"}</b></div>
      <p>${escapeHtml(item.url)}</p>
      <div class="metrics"><span><small>HTTP</small>${item.status ?? "—"}</span><span><small>ОТВЕТ</small>${item.latency} ms</span><span><small>ПОПЫТКА</small>${item.attempt}</span></div>
      ${item.error ? `<div class="error">${escapeHtml(item.error)}</div>` : ""}
    </article>`).join("");
  return `<!doctype html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>UptimePulse Report</title><style>
  :root{color-scheme:dark;--bg:#070a09;--panel:#0c1210;--line:#26302a;--text:#eef4ef;--muted:#7f8b84;--lime:#b8ff43;--red:#ff6868;font-family:Inter,system-ui,sans-serif}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 72% 0,rgba(184,255,67,.12),transparent 32%),var(--bg);color:var(--text)}main{width:min(1120px,calc(100% - 36px));margin:auto;padding:62px 0 80px}.eyebrow{font:700 10px ui-monospace;color:var(--lime);letter-spacing:.16em}h1{font-size:clamp(50px,8vw,94px);line-height:.9;letter-spacing:-.07em;margin:22px 0 18px}h1 span{color:var(--lime)}.subtitle{color:#9ba79f;max-width:600px;line-height:1.6}.summary{display:grid;grid-template-columns:repeat(4,1fr);border:1px solid var(--line);margin:45px 0 22px;background:rgba(11,16,13,.7)}.summary div{padding:22px;border-right:1px solid var(--line)}.summary div:last-child{border:0}.summary small,.metrics small{display:block;color:var(--muted);font:9px ui-monospace;letter-spacing:.1em;margin-bottom:8px}.summary b{font-size:30px}.summary .good{color:var(--lime)}.services{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.service{border:1px solid var(--line);background:var(--panel);padding:20px}.service__top{display:flex;align-items:center;gap:10px}.service__top .dot{width:8px;height:8px;border-radius:50%;background:var(--red);box-shadow:0 0 16px rgba(255,104,104,.5)}.service.ok .dot{background:var(--lime);box-shadow:0 0 16px rgba(184,255,67,.5)}.service__top b{margin-left:auto;font:700 9px ui-monospace;color:var(--red)}.service.ok .service__top b{color:var(--lime)}.service p{color:var(--muted);font:11px ui-monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.metrics{display:grid;grid-template-columns:repeat(3,1fr);border-top:1px solid var(--line);margin-top:18px;padding-top:16px}.metrics span{font:700 16px ui-monospace}.error{margin-top:14px;padding:10px;background:#281214;color:#ff9e9e;font-size:11px}.foot{margin-top:22px;color:#59645e;font:10px ui-monospace}@media(max-width:700px){.summary,.services{grid-template-columns:1fr 1fr}.summary div:nth-child(2){border-right:0}.summary div:nth-child(-n+2){border-bottom:1px solid var(--line)}}@media(max-width:470px){.services{grid-template-columns:1fr}.summary b{font-size:22px}}
  </style></head><body><main><p class="eyebrow">TWIN.CODE / SERVICE MONITOR</p><h1>Системы<br><span>на связи.</span></h1><p class="subtitle">Проверка доступности, времени ответа и обязательного содержимого. Автономный отчёт UptimePulse.</p><section class="summary"><div><small>СЕРВИСОВ</small><b>${report.summary.total}</b></div><div><small>ДОСТУПНО</small><b class="good">${report.summary.online}</b></div><div><small>УСПЕШНО</small><b>${report.summary.availability}%</b></div><div><small>СРЕДНИЙ ОТВЕТ</small><b>${report.summary.averageLatency} ms</b></div></section><section class="services">${cards}</section><p class="foot">Проверено ${escapeHtml(report.generatedAt)} · UptimePulse 1.0</p></main></body></html>`;
}

try {
  const config = JSON.parse(await readFile(configPath, "utf8"));
  if (!Array.isArray(config.targets) || !config.targets.length) throw new Error("В конфигурации нет targets");
  const started = performance.now();
  const results = await runPool(config.targets, Math.max(1, config.concurrency || 4));
  const online = results.filter((item) => item.ok).length;
  const report = {
    generatedAt: new Date().toISOString(),
    durationMs: Math.round(performance.now() - started),
    summary: {
      total: results.length,
      online,
      offline: results.length - online,
      availability: Number((online / results.length * 100).toFixed(1)),
      averageLatency: Math.round(results.reduce((sum, item) => sum + item.latency, 0) / results.length)
    },
    results
  };
  await Promise.all([
    writeFile(jsonPath, `${JSON.stringify(report, null, 2)}\n`, "utf8"),
    writeFile(htmlPath, buildHtml(report), "utf8")
  ]);
  console.log(`UptimePulse: ${online}/${results.length} online, ${report.summary.averageLatency} ms avg`);
  console.log(`Reports: ${jsonPath}, ${htmlPath}`);
  process.exitCode = online === results.length ? 0 : 2;
} catch (error) {
  console.error(`UptimePulse error: ${error.message}`);
  process.exitCode = 1;
}
