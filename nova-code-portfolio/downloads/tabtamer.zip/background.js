chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "save-session") return;
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const lastSession = tabs
    .filter((tab) => tab.url?.startsWith("http"))
    .map(({ title, url, pinned }) => ({ title, url, pinned }));
  await chrome.storage.local.set({ lastSession, savedAt: Date.now() });
});
