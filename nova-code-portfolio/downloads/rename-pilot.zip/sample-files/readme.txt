This file is ignored because rules.json only includes image extensions.
