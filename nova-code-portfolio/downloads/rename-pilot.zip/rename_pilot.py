#!/usr/bin/env python3
"""Safe batch file renamer with dry-run, collision checks and undo manifests."""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class RenameItem:
    source: str
    target: str
    status: str
    reason: str = ""


def slugify_name(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^\w\-а-яё]+", "-", value, flags=re.IGNORECASE)
    return re.sub(r"-{2,}", "-", value).strip("-")


def transform(stem: str, rule: dict, index: int) -> str:
    result = stem
    if rule.get("find"):
        flags = 0 if rule.get("caseSensitive") else re.IGNORECASE
        result = re.sub(rule["find"], rule.get("replace", ""), result, flags=flags)
    if rule.get("normalizeSpaces", True):
        result = re.sub(r"[\s_]+", " ", result).strip()
    style = rule.get("case", "keep")
    if style == "lower":
        result = result.lower()
    elif style == "upper":
        result = result.upper()
    elif style == "title":
        result = result.title()
    elif style == "slug":
        result = slugify_name(result)
    number = ""
    if rule.get("numbering"):
        number = str(index + int(rule.get("numberStart", 1))).zfill(int(rule.get("numberWidth", 2)))
        number = f"{number}{rule.get('numberSeparator', '_')}"
    return f"{rule.get('prefix', '')}{number}{result}{rule.get('suffix', '')}" or stem


def collect_files(root: Path, rule: dict) -> list[Path]:
    iterator = root.rglob("*") if rule.get("recursive", False) else root.glob("*")
    extensions = {item.lower().lstrip(".") for item in rule.get("extensions", [])}
    files = [path for path in iterator if path.is_file()]
    if extensions:
        files = [path for path in files if path.suffix.lower().lstrip(".") in extensions]
    return sorted(files, key=lambda path: str(path).lower())


def create_plan(root: Path, rule: dict) -> list[RenameItem]:
    files = collect_files(root, rule)
    reserved = {path.resolve() for path in files}
    planned_targets: set[Path] = set()
    plan: list[RenameItem] = []
    for index, source in enumerate(files):
        next_stem = transform(source.stem, rule, index)
        extension = source.suffix.lower() if rule.get("lowercaseExtensions") else source.suffix
        target = source.with_name(f"{next_stem}{extension}")
        source_resolved = source.resolve()
        target_resolved = target.resolve()
        status, reason = "ready", ""
        if source.name == target.name:
            status, reason = "skip", "Имя уже соответствует правилу"
        elif target_resolved in planned_targets:
            status, reason = "blocked", "Два файла получают одинаковое имя"
        elif target_resolved.exists() and target_resolved != source_resolved and target_resolved not in reserved:
            status, reason = "blocked", "Целевой файл уже существует"
        planned_targets.add(target_resolved)
        plan.append(RenameItem(str(source), str(target), status, reason))
    return plan


def apply_plan(plan: list[RenameItem]) -> None:
    ready = [item for item in plan if item.status == "ready"]
    if any(item.status == "blocked" for item in plan):
        raise RuntimeError("План содержит конфликты. Применение отменено.")
    temporary: list[tuple[Path, Path, Path]] = []
    for index, item in enumerate(ready):
        source, target = Path(item.source), Path(item.target)
        temp = source.with_name(f".__rename_pilot_{index}_{source.name}")
        source.rename(temp)
        temporary.append((temp, source, target))
    try:
        for temp, _, target in temporary:
            temp.rename(target)
    except Exception:
        for temp, original, target in reversed(temporary):
            current = target if target.exists() else temp
            if current.exists():
                current.rename(original)
        raise


def undo_manifest(path: Path) -> int:
    report = json.loads(path.read_text(encoding="utf-8"))
    restored = 0
    for item in reversed(report["items"]):
        source, target = Path(item["source"]), Path(item["target"])
        if item["status"] == "ready" and target.exists() and not source.exists():
            target.rename(source)
            restored += 1
    return restored


def render_html(report: dict) -> str:
    rows = []
    for item in report["items"]:
        source = Path(item["source"]).name
        target = Path(item["target"]).name
        rows.append(
            f'<tr class="{item["status"]}"><td><span>{html.escape(item["status"].upper())}</span></td>'
            f'<td>{html.escape(source)}</td><td>→</td><td>{html.escape(target)}</td>'
            f'<td>{html.escape(item["reason"] or "Готово к переименованию")}</td></tr>'
        )
    stats = report["summary"]
    return f"""<!doctype html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RenamePilot Report</title><style>
    :root{{color-scheme:dark;--bg:#07090c;--panel:#0d1116;--line:#272e36;--text:#eef2f5;--muted:#7b8691;--lime:#b8ff43;--red:#ff6d6d;font-family:Inter,system-ui,sans-serif}}*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(circle at 80% 0,rgba(184,255,67,.12),transparent 30%),var(--bg);color:var(--text)}}main{{width:min(1120px,calc(100% - 36px));margin:auto;padding:62px 0 80px}}.eyebrow{{font:700 10px ui-monospace;color:var(--lime);letter-spacing:.17em}}h1{{font-size:clamp(52px,8vw,96px);line-height:.88;letter-spacing:-.07em;margin:22px 0}}h1 span{{color:var(--lime)}}.lead{{color:#9ba5ad;line-height:1.6;max-width:610px}}.summary{{display:grid;grid-template-columns:repeat(4,1fr);margin:42px 0 18px;border:1px solid var(--line);background:rgba(12,16,20,.75)}}.summary div{{padding:20px;border-right:1px solid var(--line)}}.summary div:last-child{{border:0}}.summary small{{display:block;color:var(--muted);font:9px ui-monospace;letter-spacing:.1em;margin-bottom:8px}}.summary b{{font-size:30px}}.summary .accent{{color:var(--lime)}}.table-wrap{{overflow:auto;border:1px solid var(--line);background:var(--panel)}}table{{width:100%;border-collapse:collapse;min-width:780px}}th,td{{padding:15px 13px;border-bottom:1px solid var(--line);text-align:left;font-size:12px}}th{{color:var(--muted);font:9px ui-monospace;letter-spacing:.08em}}td:nth-child(3){{color:var(--lime)}}td:last-child{{color:var(--muted)}}td span{{font:700 8px ui-monospace;color:var(--lime);border:1px solid #425533;padding:5px}}tr.blocked td span{{color:var(--red);border-color:#623636}}tr.skip td span{{color:#84909b;border-color:#3a444d}}.foot{{color:#59636b;font:10px ui-monospace;margin-top:18px}}@media(max-width:620px){{.summary{{grid-template-columns:1fr 1fr}}.summary div:nth-child(2){{border-right:0}}.summary div:nth-child(-n+2){{border-bottom:1px solid var(--line)}}}}
    </style></head><body><main><p class="eyebrow">TWIN.CODE / FILE OPERATIONS</p><h1>Сначала план.<br><span>Потом действие.</span></h1><p class="lead">RenamePilot показывает каждое новое имя, останавливается при конфликте и сохраняет манифест для отката.</p><section class="summary"><div><small>ФАЙЛОВ</small><b>{stats['total']}</b></div><div><small>ГОТОВО</small><b class="accent">{stats['ready']}</b></div><div><small>ПРОПУЩЕНО</small><b>{stats['skip']}</b></div><div><small>КОНФЛИКТОВ</small><b>{stats['blocked']}</b></div></section><div class="table-wrap"><table><thead><tr><th>СТАТУС</th><th>ИСХОДНОЕ ИМЯ</th><th></th><th>НОВОЕ ИМЯ</th><th>КОММЕНТАРИЙ</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div><p class="foot">Режим: {html.escape(report['mode'])} · создано {html.escape(report['generatedAt'])}</p></main></body></html>"""


def main() -> int:
    parser = argparse.ArgumentParser(description="Безопасное пакетное переименование файлов")
    parser.add_argument("folder", nargs="?", help="Папка с файлами")
    parser.add_argument("--rules", default="rules.json", help="JSON с правилами")
    parser.add_argument("--apply", action="store_true", help="Применить план")
    parser.add_argument("--undo", metavar="REPORT", help="Откатить применённый манифест")
    parser.add_argument("--json", default="report.json", help="Путь JSON-отчёта")
    parser.add_argument("--html", default="report.html", help="Путь HTML-отчёта")
    args = parser.parse_args()
    if args.undo:
        restored = undo_manifest(Path(args.undo))
        print(f"RenamePilot: восстановлено файлов: {restored}")
        return 0
    if not args.folder:
        parser.error("укажите папку с файлами")
    root = Path(args.folder).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Папка не найдена: {root}")
    rule = json.loads(Path(args.rules).read_text(encoding="utf-8"))
    plan = create_plan(root, rule)
    summary = {name: sum(item.status == name for item in plan) for name in ("ready", "skip", "blocked")}
    summary["total"] = len(plan)
    report = {
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "root": str(root),
        "mode": "apply" if args.apply else "dry-run",
        "rules": rule,
        "summary": summary,
        "items": [asdict(item) for item in plan],
    }
    Path(args.json).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    Path(args.html).write_text(render_html(report), encoding="utf-8")
    if args.apply:
        apply_plan(plan)
    print(f"RenamePilot: {summary['ready']} ready, {summary['skip']} skip, {summary['blocked']} blocked")
    print(f"Mode: {report['mode']}. Reports: {args.json}, {args.html}")
    return 2 if summary["blocked"] else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"RenamePilot error: {error}", file=sys.stderr)
        raise SystemExit(1)
